﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Academico.Migrations
{
    public partial class AlunoDisciplinaFKS : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_AlunosDisciplinas",
                table: "AlunosDisciplinas");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AlunosDisciplinas",
                table: "AlunosDisciplinas",
                columns: new[] { "AlunoId", "DisciplinaId", "Ano", "Semestre" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_AlunosDisciplinas",
                table: "AlunosDisciplinas");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AlunosDisciplinas",
                table: "AlunosDisciplinas",
                columns: new[] { "AlunoId", "DisciplinaId" });
        }
    }
}
